// tabs changes
jQuery(document).ready(function ($) {
  jQuery(".nft-tab-content:nth-of-type(1)").show();
  jQuery(".tabs-menu .tabs").on("click", function (event) {
    jQuery(".nft-tab-content").addClass("eff");
    var target = $(this).attr("id");
    console.log(target);
    jQuery(".nft-tab-content").hide();
    jQuery("[data-section=" + target + "]").show();
  });
});

// Slick slider

$(document).ready(function ($) {
  $(".brands-slider").slick({
    slidesToShow: 10,
    infinite: true,
    autoplay: true,
    speed: 1000,
    autoplaySpeed: 300,
  });
});
// Testimonal slider
$(document).ready(function ($) {
  $(".testimonal-slider").slick({
    slidesToShow: 3,
    slidesToScroll: 3,
    infinite: true,
    autoplay: false,
    variableWidth: true,
    arrows: true,
    prevArrow: $(".prev"),
    nextArrow: $(".next"),
  });
});

//Developer Tool Tab change
$(document).ready(function ($) {
  $(".click-tab").click(function () {
    if ($(this).hasClass("developer-tool-Sa-inner-content")) {
      return;
    }
    console.log("yes this is active");
  });
});

// Resources  To Scale Drop-down

// step-1 toggle the menu drop-down
$(document).ready(function () {
  $(".value").html($(".menu-items.first").data("text"));
  $(".drop-down-menu").hide();
  $(".drop-down-header").click(function () {
    $(".drop-down-menu").toggle();
  });

  // step-2 when select the active li rest will hide.
  $(".drop-down-menu li").click(function () {
    var text = $(this).data("text");
    $(".value").html(text);
    $(".drop-down-menu").hide();
  });
});
